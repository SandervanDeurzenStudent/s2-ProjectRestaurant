using System;
using Xunit;
namespace RestaurantReservationTests
{
    public class Tests
    {
        [Fact]
        public void Test1()
        {

        }
        [Test]
        public void addToWagon_WagonAddToWagon_ReturnTrue()
        {
            //Arrange
            //act
            //Assert
        }
    }
}
