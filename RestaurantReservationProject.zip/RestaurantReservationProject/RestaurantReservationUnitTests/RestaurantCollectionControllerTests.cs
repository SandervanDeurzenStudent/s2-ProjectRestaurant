using BusinessLogic.Models;
using BusinessLogic.Restraurants;
using NUnit.Framework;
    using System.Collections.Generic;

    namespace Tests
    {
        public class RestaurantCollectionControllerTests
        {
            [SetUp]
            public void Setup()
            {
            }

        
            [Test]
            public void getList_returnList()
            {
            //Arrange
            var f = new RestaurantCollectionController();
            //act
            var result = f.getRestaurantById(18);
            //Assert
            Assert.AreEqual(new Restaurant("Sander van Deurzen", "tfyutrd", "Duigendreef 27", 637313244, "sander.vandeurzen @ziggo.nl"), (new Restaurant("Sander van Deurzen", "tfyutrd", "Duigendreef 27", 637313244, "sander.vandeurzen @ziggo.nl")));
            }
        }
    }