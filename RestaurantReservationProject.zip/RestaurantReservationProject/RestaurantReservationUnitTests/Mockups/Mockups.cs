﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestaurantReservationUnitTests.Mockups
{
    class Mockups
    {
    }
}
