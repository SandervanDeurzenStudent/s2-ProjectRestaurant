﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using Presentation.Controllers;
using System.Threading.Tasks;


namespace RestaurantReservationUnitTests
{
    class RestaurantViewControllerTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void getList_returnList()
        {
            //Arrange
           // var restaurantViewController = new RestaurantViewController();
            //act
           // var result = restaurantViewController.Edit(1);
            //assert
           // Assert.IsNotEmpty(result.ToString());
        }
    }
}
