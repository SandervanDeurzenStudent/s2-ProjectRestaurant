﻿using System;

namespace LogicBridge
{
    public class Restaurant
    {

    }
}
